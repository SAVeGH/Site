/*
������� ����������� ���������
����
a * x^2 + b * x + c = 0
*/
create or alter function Resolve(@a float, @b float, @c float )
returns 
@result table(IsValid bit, x1 float, x2 float)
as
begin

declare
@x1 float = 0.0, 
@x2 float = 0.0,
@IsValid bit = 0.0;

if(@a = 0.0)
begin

	if(@b != 0.0)
	begin
		set @x1 = -@c / @b;
		set @x2 = @x1;

		insert into @result(IsValid, x1 , x2 )
		values(1, @x1, @x2);

		return;
	end

	insert into @result(IsValid, x1 , x2 )
	values(0, @x1, @x2);

	return;
end

if((@b = 0.0) and (@c = 0.0))
begin
	insert into @result(IsValid, x1 , x2 )
	values(1, @x1, @x2);

	return;
end

-- @b or @c != 0

if(@c = 0)
begin
	set @x2 = -@b / @a;

	insert into @result(IsValid, x1 , x2 )
	values(1, @x1, @x2);

	return;
end

if(@b = 0)
begin

	declare @caRelation float = -@c / @a;

	if (@caRelation < 0.0)
	begin
		insert into @result(IsValid, x1 , x2 )
		values(0, @x1, @x2);

		return;
	end

	set @x1 = Sqrt(@caRelation);
    set @x2 = -@x1;

	insert into @result(IsValid, x1 , x2 )
	values(1, @x1, @x2);

	return;
end

-- @b and @c != 0

declare @descriminant float = Power(@b, 2) - 4.0 * @a * @c;

if (@descriminant < 0.0)
begin

    insert into @result(IsValid, x1 , x2 )
	values(0, @x1, @x2);

	return;
end

declare @descrimRoot float = Sqrt(@descriminant);
declare @divisor float = 2.0 * @a;

set @x1 = (-@b - @descrimRoot) / @divisor;
set @x2 = (-@b + @descrimRoot) / @divisor;

insert into @result(IsValid, x1 , x2 )
values(1, @x1, @x2);

return
end
go